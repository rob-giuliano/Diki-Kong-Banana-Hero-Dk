 <!-- div wrap wp -->
 <div class="wrap">

 <!-- Name of Plugin Indicator -->
 <h2>Diki Kong Banana Hero Dk</h2> 
 <!-- End name of Plugin Indicator -->
 
 <!-- Div Style value info plugin -->
    <div style="font-size: 18px;">by <a href="http://rg-develop.net" target="_blank">Rob Giuliano Developer</a></div><br>
 <!-- End div Style value info plugin -->     
 
 <!-- activ tab plugin  get page --> 
	<?php
        if( isset( $_GET[ 'page' ] ) ) {
            $active_tab = $_GET[ 'page' ];
        } // end if
    ?>
 <!-- end activ tab plugin get page --> 

 <!-- Class navigation tab -->
   <h2 class="nav-tab-wrapper">
 <!-- Tab name, link && page activate value -->
        <a href="?page=dk_banana_hero" class="nav-tab <?php echo $active_tab == 'dk_banana_hero' ? 'nav-tab-active' : ''; ?>">Diki Kong Banana Hero Dk </a>
 <!-- End tab name, link && page activate value -->   
   </h2>
 <!-- End class navigation tab -->

 </div>
 <!-- End div wrap wp -->