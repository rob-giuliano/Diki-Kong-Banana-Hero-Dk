
 <!-- /************** INCLUDES ******************/ -->
 <?php include 'interface.php' ?>

 <!-- div class wp -->
 <div class="wrap regenthumbs"> 
	<br/>
 <!-- Description plugin property -->
	<p>Generate your shortcode [game] bellow and put to your post, page, widget, etc.</p>
	<p><strong>*Info:</strong> If your site is run over <b>(HTTPS)</b> you need to load a game that are loaded over (HTTPS)-link, or your shortcode can't be loaded.</p>
 <!-- End description plugin property -->  

 <!--Table  Form  shortcode generator -->
   <table>
	<table class="form-table">
        <tr><th scope="row"></th>
        <td><input type="checkbox" id="dk_scale" checked="checked" /> Check this option if you want to make it full width - template grid</td></tr>
        <tr valign="top">
        <th scope="row">
        <a type="submit" style="font-weight: normal;" class="button-primary" name="submit-generate" value="Generate" onclick="generate_shortcode();">Generate shortcode</a>
        </th>
        <td><code id="shortcode_gen" type="text" readonly="" onclick="this.select()" style="font-size: 17px; padding: 6px 12px; border-radius: 4px;"><i>[generate code]</i></code><br>
    	</td></tr>
    </table>
 <!-- Submit button generator shortcode -->
    <p class="submit"></p>	
    </table>
 <!-- End table  Form  shortcode generator -->
 </div>
 <!-- end div class wp -->

 <!-- JS -->
 <script>
    /* Function  generate shortcode*/
	function generate_shortcode() {
		var get_element = document.getElementById("shortcode_gen");
		var dk_url = 'diki_kong_banana_hero_dk';    // variable url value
		var dk_width = 'diki_kong_banana_hero_dk';  // variable width value
		var dk_height = 'diki_kong_banana_hero_dk'; // variable height value
		var game_dk_scale = document.getElementById("dk_scale").checked; // scale option check option

        // Prepare conditions
		if (dk_url = 'diki_kong_banana_hero_dk') { // url game link
			game_dk_url = ' url="<?php echo 'http://'.$_SERVER['HTTP_HOST'].''; ?>/wp-content/plugins/dk_banana_hero/assets/game/" ';
		}
		if (dk_width = 'diki_kong_banana_hero_dk') {
			game_dk_width = ' width="950"'; // width - default value
		}
		if (dk_height = 'diki_kong_banana_hero_dk') {
			game_dk_height = ' height="630"'; // height - default value
		}
		if (game_dk_scale == true) { // scale check value option
			dk_scale = ' scale="false"';
		}
		else{
			dk_scale = ' scale="true"';
		}
		// Collect other data - to generate shortcode
		if (game_dk_url != '' && game_dk_width != '' && game_dk_height != '') {
	    // Get the content of shortcode
			get_element.innerHTML = '[dk_banana_hero_dk'+game_dk_url+''+game_dk_width+''+game_dk_height+''+dk_scale+']';

		}
	}
 </script>
 <!-- END JS -->