<?php
/**
 * Plugin Name: Diki Kong Banana Hero Dk
 * Description: Add game  by shortcode [embed] to pages, posts, widget, etc - easily manage and display.
 * Plugin URI: #
 * Author: Rob Giuliano
 * Author URI: http://rg-develop.net
 * Version: 1.0
 * Requires at least: 4.5
 * Tested up to: 5.4.2
 * License URI: https://opensource.org/licenses/MIT
 */

defined('ABSPATH') or die('abcd');
// function dk game
function dk_game() {
  add_menu_page('Dk Banana Hero', 'Dk Banana Hero', 'manage_options', 'dk_banana_hero', 'diki_game_integration');
}
// Plugin Title
add_action("admin_menu", "dk_game");

/************** INCLUDES ******************/
function diki_game_integration() {
  include 'includes/dk.php';
}

// Prepare attributes
function dk_banana_hero_dk($atts){
  $a = shortcode_atts( array(
    'url' => '',    // url value
    'width' => '',  // width value
    'height' => '', // height value
    'scale' => '',  // scale value option
    'percent' => '' // percent value option
    ), $atts);
  $dk_scale = $a['scale']; // variable dk_scale
  // Prepare  variable attributes
  $dk_scale_a = '';
  $dk_scale_b = '';
  
  // Set percent defaults
  $a['percent'] = round($a['height']/$a['width']*100);
  echo diki_get_style(); 
  // Completize all parms
  echo "<style>.diki { padding-bottom: {$a['percent']}%; } .diki-game-width {}</style>";
  if ($dk_scale =='false') {
    $dk_scale_a = "<div style=\"max-width: {$a['width']}px;\">";
    $dk_scale_b = "</div>";
  }
  return "{$dk_scale_a}<div class=\"diki\"><iframe src=\"{$a['url']}\" frameborder=\"0\"></iframe></div>{$dk_scale_b}";
}
add_shortcode('dk_banana_hero_dk', 'dk_banana_hero_dk'); //shortcode value

//function get style from css
function diki_get_style() {
	wp_register_style('style', plugin_dir_url(__FILE__) . 'static/css/style.css');
	wp_enqueue_style('style');
}

add_action('wp_enqueue_scripts', 'diki_get_style');
?>