
=== Diki Kong Banana Hero ===

Contributors: Rob Giuliano
Tags: plugin, game, hero, diki, embed, shortcode
Requires at least: 4.0
Tested up to: 5.4.1
Stable tag: 1.0
License: MIT


== Description ==

By using this plugin, you can embed "Diki Kong Banana Hero Dk" game into your WordPress post, page or widget easily.


Features:

* Your content will fit on any screen size.
* Shortcode generator.
* Easy to use.

== Installation ==

Upload the "dk_banana_hero" plugin into your blog, Activate it.