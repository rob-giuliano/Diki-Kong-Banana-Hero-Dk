 /* Options file
 ================*/

'use strict';

// --> Options variable
var Options = function(game) {};
Options.prototype = {
  menuConfig: {
    className: "inverse",
    startY: 260,
    startX: "center",
    verticalSpacing: (game.world.height > game.world.width ? 80 : 60)
  },

  // --> menu option - 'back button' align
  addMenuOption8: function(button_back,  callback) {
    var button_back = this.add.sprite(game.world.centerX-(12), 512,'back_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      button_back.useHandCursor = true; //hand cursor option

    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      button_back.useHandCursor = true; //hand cursor option

    };
	// --> button back  
    button_back.inputEnabled = true;
	button_back.useHandCursor = true;
	button_back.input.useHandCursor = true; //hand cursor option
    button_back.events.onInputUp.add(callback, this);
    button_back.events.onInputOver.add(onOver, this);
    button_back.events.onInputOut.add(onOut, this);
	
  },
  
 // --> Audio function management
  manageAudio: function() {
		gameOptions.playMusic =! gameOptions.playMusic;
        music.volume = gameOptions.playMusic ? 1 : 0;   // sound on/off 
		this.audioButton.animations.play(gameOptions.playMusic);

	},
  
   
  create: function () {
	this.game.add.sprite(122, 0, 'replay_ground').scale.setTo(0.29);	
    this.stage.disableVisibilityChange = true;
	// --> music function
    if (music.name !== "intro_sound" && gameOptions.playMusic) {
      music.stop();
      music = game.add.audio('intro_sound');
      music.loop = true;
      music.play(); 
    }
	
	// --> audio button 
	this.audioButton = this.add.button(game.world.centerX-(-37), 460, 'sound_button', this.manageAudio, this);
	this.audioButton.anchor.set(1,0);
	this.audioButton.input.useHandCursor = true;
	this.audioButton.animations.add('true', [0], 10, true);
	this.audioButton.animations.add('false', [1], 10, music.volume, true);
	this.audioButton.animations.play(gameOptions.playMusic);
    this.menuGroup = game.add.group();
    this.addMenuOption8 ('button_back', function () {
	  game.state.start("GameMenu");
    }, this.menuGroup);
  },
};

// --> create icon button (style)
function makeIconBtn (txt, callback, className, _style){
      txt.anchor.setTo(0.5);
      txt.inputEnabled = true;

      txt.events.onInputUp.add(callback);
      txt.events.onInputOver.add(function (target) {
        target.setStyle(fa_style.navitem.hover);
      });
      txt.events.onInputOut.add(function (target) {
        target.setStyle(fa_style.navitem[className]);
      });
}
Phaser.Utils.mixinPrototype(Options.prototype, mixins);