/*
Project name: Diki Kong Banana Hero Dk
Author: Rob Giuliano
Version: 1.0

Table of contents:
------------------

     1. Function 'Diki_Kong' game 
     2. Characters game
	    -> ork one
		-> ork two
		-> ork three
		-> ork four
		-> crocco
		-> bird
	 3. Inherit Phaser Characters
     4. PlayState
     5. Update
     6. Collision
     7. Handle Input character 'diki'
     8. Load level
     9.Spawn platform
     10.Spawn enemy wall
     11.Spawn all characters
     12.Hud aria
     13.Start game

*/

 /* 1.Function 'Diki_Kong'
 ==========================================*/
function Diki_Kong(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, 'diki');
    this.anchor.set(0.5, 0.5);
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = true;
    this.animations.add('stop', [0]);
    this.animations.add('run', [1, 2, 3, 4], 12, true); // 8fps
    this.animations.add('jump', [5]);
    this.animations.add('fall', [4]); 
};

//Diki_Kong Phaser.Sprite
Diki_Kong.prototype = Object.create(Phaser.Sprite.prototype);
Diki_Kong.prototype.constructor = Diki_Kong;
Diki_Kong.prototype.move = function (direction) {
    const SPEED = 200;
    this.body.velocity.x = direction * SPEED;
    // update image flipping & animations
    if (this.body.velocity.x < 0) {
        this.scale.x = -1;
    }
    else if (this.body.velocity.x > 0) {
        this.scale.x = 1;
    }
};
var Game = function(Diki_Kong) {};	
Diki_Kong.prototype.jump = function () {
    const JUMP_SPEED = 620;
    let canJump = this.body.touching.down;
    if (canJump) {
        this.body.velocity.y = -JUMP_SPEED;
    }
    return canJump;
};
Diki_Kong.prototype.bounce = function () {
    const BOUNCE_SPEED = 200;
    this.body.velocity.y = -BOUNCE_SPEED;  
};

Diki_Kong.prototype.update = function () {
    // update sprite animation, if it needs changing
    let animationName = this._getAnimationName();
    if (this.animations.name !== animationName) {
        this.animations.play(animationName);
    }
};

Diki_Kong.prototype._getAnimationName = function () {
    let name = 'stop';
    // jumping
    if (this.body.velocity.y < 0) {
        name = 'jump'; 
    }
    // falling
    else if (this.body.velocity.y >= 0 && !this.body.touching.down) {
        name = 'fall';
    }
    else if (this.body.velocity.x !== 0 && this.body.touching.down) {
        name = 'run';
    }
    return name; 
};

 /* 2.Characters game
==========================================*/
// --> Character ork one

function orky_one(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_enemy_ork_one');
    this.anchor.set(0.5, 0.5);
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 7, 8, 9, 10, 11, 12, 7, 8, 9, 10, 11, 12, 13], 5, true); // 8fps, looped
    this.animations.add('die', [14, 15, 16], 8);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = orky_one.SPEED;
}

orky_one.SPEED = 79; //speed ork one


// --> Character ork two
function orky_two(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_enemy_ork_two');
    // anchor
    this.anchor.set(0.5, 0.5); 
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 7, 8, 9, 10, 11, 12, 7, 8, 9, 10, 11, 12, 13], 5, true); // 8fps, looped
    this.animations.add('die', [14, 15, 16], 8);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = orky_two.SPEED;
}
orky_two.SPEED = 79; //speed ork two

// --> Character ork three
function orky_three(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_enemy_ork_three');

    // anchor
    this.anchor.set(0.5, 0.5);
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19], 8, true); // 8fps, looped
    this.animations.add('die', [20, 21, 22], 12);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = orky_three.SPEED;
}
orky_three.SPEED = 79; //speed ork three

// --> Character ork four
function orky_four(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_enemy_ork_four');
    // anchor
    this.anchor.set(0.5, 0.5);
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19], 8, true); // 8fps, looped
    this.animations.add('die', [20, 21, 22], 12);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = orky_four.SPEED;
}
orky_four.SPEED = 79; //speed ork four

// --> Character crocco
function crocco(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_crocco');
    // anchor
    this.anchor.set(0.5, 0.5);
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17], 8, true); // 8fps, looped
    this.animations.add('die', [20, 21, 22], 8);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = crocco.SPEED;
}
crocco.SPEED = 79; //speed crocco

// --> Character bird
function bird(game, x, y) {
    Phaser.Sprite.call(this, game, x, y, '_bird');
    // anchor
    this.anchor.set(0.5, 0.5);
    // animation
    this.animations.add('crawl', [0, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2, 3, 4, 5, 6, 7, 8, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 9, 10, 11, 12, 13, 14, 15, 16, 17, 9, 10, 11, 12, 13, 14, 15, 16, 17, 9, 10, 11, 12, 13, 14, 15, 16, 17], 14, true); // 8fps, looped
    this.animations.add('die', [18, 19, 20], 5);
    this.animations.play('crawl');
    // physic properties
    this.game.physics.enable(this);
    this.body.collideWorldBounds = false;
    this.body.velocity.x = bird.SPEED;
}
bird.SPEED = 89; //speed bird


/* 3. Inherit Phaser Characters
==========================================*/
// --> inherit character Ork one
orky_one.prototype = Object.create(Phaser.Sprite.prototype);
orky_one.prototype.constructor = orky_one;
orky_one.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = orky_one.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -orky_one.SPEED; // turn right
    }
};
orky_one.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();
    }, this);
};

// --> inherit character Ork two
orky_two.prototype = Object.create(Phaser.Sprite.prototype);
orky_two.prototype.constructor = orky_two;
orky_two.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = orky_two.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -orky_two.SPEED; // turn right
    }
};
orky_two.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();
    }, this);
};

// --> inherit character Ork three
orky_three.prototype = Object.create(Phaser.Sprite.prototype);
orky_three.prototype.constructor = orky_three;
orky_three.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = orky_three.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -orky_three.SPEED; // turn right
    }
};
orky_three.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();
    }, this);
};

// --> inherit character Ork four
orky_four.prototype = Object.create(Phaser.Sprite.prototype);
orky_four.prototype.constructor = orky_four;
orky_four.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = orky_four.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -orky_four.SPEED; // turn right
    }
};
orky_four.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();
    }, this);
};

// --> inherit character Crocco
crocco.prototype = Object.create(Phaser.Sprite.prototype);
crocco.prototype.constructor = crocco;
crocco.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = crocco.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -crocco.SPEED; // turn right
    }
};
crocco.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();
    }, this);
};

// --> inherit character Bird
bird.prototype = Object.create(Phaser.Sprite.prototype);
bird.prototype.constructor = bird;
bird.prototype.update = function () {
    // check against walls and reverse direction if necessary
    if (this.body.touching.left || this.body.blocked.left) {
        this.body.velocity.x = bird.SPEED; // turn left
    }
    else if (this.body.touching.right || this.body.blocked.right) {
        this.body.velocity.x = -bird.SPEED; // turn right
    }
};
bird.prototype.die = function () {
    this.body.enable = false;
    this.animations.play('die').onComplete.addOnce(function () {
        this.kill();  
    }, this);
};

/* 4. PlayState Aria
==========================================*/

PlayState = {};
const LEVEL_COUNT = 14; //Level Number Active

// --> Keyboard keys game controller
PlayState.init = function (data) {
    this.game.renderer.renderSession.roundPixels = true;
    this.keys = this.game.input.keyboard.addKeys({
		z: Phaser.KeyCode.Z, // Sound on
		x: Phaser.KeyCode.X, // Sound off
		p: Phaser.KeyCode.P, // Pause
		shift: Phaser.KeyCode.SHIFT, // Stop game
		esc: Phaser.KeyCode.ESC, // Main menu
        left: Phaser.KeyCode.LEFT, // Diki direction left
        right: Phaser.KeyCode.RIGHT, // Diki direction right
        up: Phaser.KeyCode.UP // Diki jump
    });
 
// --> Functions  keys game controller 
    this.keys.up.onDown.add(function () {
        let didJump = this.diki.jump();
        if (didJump) {
           this.sfx.jump.play();
        }
    }, this);
	
	this.keys.esc.onDown.add(function () {
        this.game.state.start("GameMenu");
		
    }, this);
	
	this.keys.shift.onDown.add(function () {
		togglePause();
    }, this);
	
	this.keys.x.onDown.add(function () {
		this.stage.disableVisibilityChange = true;
           music.stop();   
    }, this);
	
	this.keys.z.onDown.add(function () {
        this.stage.disableVisibilityChange = true;
	     music.play();   
    }, this);

// --> PickupCount number -> default value: '0'
    this.coinPickupCount = 0;
    this.cherryPickupCount = 0;
    this.bananaPickupCount = 0;
    this.hasTrophy = false;
    this.hasTreasure = false;
	

    this.level = (data.level || 0) % LEVEL_COUNT; 	//Level count start game
	
// --> Function Pause
function togglePause() {
    game.physics.arcade.isPaused = (game.physics.arcade.isPaused) ? false : true;
 }
	
};

// --> Preload numbers level
PlayState.preload = function () {
    this.game.load.json('level:0', 'world/level/_diki_world_0.json');
    this.game.load.json('level:1', 'world/level/_diki_world_1.json');
    this.game.load.json('level:2', 'world/level/_diki_world_2.json');
	this.game.load.json('level:3', 'world/level/_diki_world_3.json');
    this.game.load.json('level:4', 'world/level/_diki_world_4.json');
    this.game.load.json('level:5', 'world/level/_diki_world_5.json');
	this.game.load.json('level:6', 'world/level/_diki_world_6.json');
    this.game.load.json('level:7', 'world/level/_diki_world_7.json');
    this.game.load.json('level:8', 'world/level/_diki_world_8.json');
	this.game.load.json('level:9', 'world/level/_diki_world_9.json');
    this.game.load.json('level:10', 'world/level/_diki_world_10.json');
    this.game.load.json('level:11', 'world/level/_diki_world_11.json');
	this.game.load.json('level:12', 'world/level/_diki_world_12.json');
    this.game.load.json('level:13', 'world/level/_diki_world_13.json');
    this.optionCount = 1;

	//Images Load Section
    this.game.load.image('font:numbers', 'images/numbers.png');
    this.game.load.image('background', 'images/_dk_bg_ground.png');
    this.game.load.image('ground', 'images/_dk_grd.png');
    this.game.load.image('grass_left', 'images/_dk_grass_left.png');
    this.game.load.image('grass_right', 'images/_dk_grass_right.png');
    this.game.load.image('grass_sky', 'images/_dk_grass_sky.png');
    this.game.load.image('std_g1', 'images/_dk_std_g1.png');
	this.game.load.image('std_g2', 'images/_dk_std_g2.png');
    this.game.load.image('std_g1_r', 'images/_dk_std_g1_right.png');
    this.game.load.image('std_g1_l', 'images/_dk_std_g1_left.png');
    this.game.load.image('std_g2_r', 'images/_dk_std_g1_right.png');
    this.game.load.image('std_g2_l', 'images/_dk_std_g2_left.png');
    this.game.load.image('std_g3', 'images/_dk_std_g3.png');
    this.game.load.image('std_g3_r', 'images/_dk_std_g3_right.png');
    this.game.load.image('std_g3_l', 'images/_dk_std_g3_left.png');
    this.game.load.image('std_g4_F', 'images/_dk_std_g4.png');
    this.game.load.image('grf_t_root', 'images/_dk_base_root.png');
    this.game.load.image('grf_t_box_l', 'images/_dk_box_wood_L_1.png');
    this.game.load.image('grf_t_box_r', 'images/_dk_box_wood_R_1.png');
    this.game.load.image('grf_t_pannel', 'images/_dk_info_pannel.png');
    this.game.load.image('dk_cherry', 'images/images/_dk_cherry_point.png');
    this.game.load.image('dk_banana', 'images/_dk_banana.png');
    this.game.load.image('dk_cherry',  'images/_dk_cherry.png');
    this.game.load.image('cherry',  'images/_dk_cherry_point.png');
    this.game.load.image('icon:coin',  'images/_dk_coin_score.png');
    this.game.load.image('banana',  'images/_dk_banana_scr.png');
    this.game.load.image('grf_t_bush', 'images/_dk_basic_bush_grd.png');
    this.game.load.image('grf_t_bush_l', 'images/_dk_basic_bush_l.png');
    this.game.load.image('grf_t_bush_r', 'images/_dk_basic_bush_r.png');
    this.game.load.image('mush_1', 'images/_dk_mush_1.png');
    this.game.load.image('mush_2', 'images/_dk_mush_2.png');
    this.game.load.image('tree_1', 'images/_dk_three_1.png');
    this.game.load.image('invisible-wall', 'images/_diki_point_inv.png');
    this.game.load.image('diamond', 'images/diamond.png');
    this.game.load.image('menu', 'images/number-buttons-90x90.png', 270, 180);
    this.game.load.image('background_1', 'images/bubble-on.png');
	this.game.load.image('bush_pass_1', 'images/_dk_basic_bush_grd.png', 64, 62);
	this.game.load.image('tree_pass_1', 'images/_dk_three_1.png', 141, 150);
	this.game.load.image('tree_pass_2', 'images/_dk_three_1.png', 141, 150);
    this.game.load.image('box_pass_1', 'images/_dk_box_basic.png', 64, 62);
    this.game.load.image('mush_pass_1', 'images/_dk_mush_1.png', 64, 62);
    this.game.load.image('mush_pass_2', 'images/_dk_mush_2.png', 64, 62);
	this.game.load.image('diki_control_tab', 'images/_diki_control_tab.png');
	this.game.load.image('close', 'images/close.png');
    this.game.load.image('trophy', 'images/_dk_base_trophy.png');
    this.game.load.image('treasure', 'images/_dk_treasure_bag.png');
    
	//Spritesheet Icons
    this.game.load.spritesheet('icon:trophy', 'images/_dk_trophy_icon.png', 34, 30);
    this.game.load.spritesheet('icon:treasure', 'images/_dk_treasure_icon.png', 34, 30);
    this.game.load.spritesheet('icon:cherry',  'images/_dk_cherry_point.png', 35, 36);
    this.game.load.spritesheet('icon:banana',  'images/_dk_banana_icon.png', 35, 36);
	 
    //Spritesheet load
	this.game.load.spritesheet('button', 'images/button_sprite_sheet.png', 193, 71);
	this.game.load.spritesheet('ctrl_tab_one', 'images/_diki_ctrl_tab_one.png');
	this.game.load.spritesheet('ctrl_tab_two', 'images/_diki_ctrl_tab_two.png');

	//Spritesheet section
	this.game.load.spritesheet('coin', 'images/_dk_coin_point.png', 23, 23);
	this.game.load.spritesheet('access_dir', 'images/_dk_dir_1.png', 64, 62);
    this.game.load.spritesheet('out_dir', 'images/_dk_dir_2.png', 64, 62);
    this.game.load.spritesheet('diki', 'images/diki.png', 118, 59);
    this.game.load.spritesheet('point_out', 'images/_dk_point_out.png', 42, 66);
	this.game.load.spritesheet('sound_on', 'images/_diki_sound_on.png');
	this.game.load.spritesheet('sound_off', 'images/_diki_sound_off.png');
	this.game.load.spritesheet('button-audio', 'images/button-audio.png', 35, 35);
    this.game.load.spritesheet('_enemy_ork_one', 'images/_spd_ork_one.png', 80, 63);
    this.game.load.spritesheet('_enemy_ork_two', 'images/_spd_ork_two.png', 81, 63);
    this.game.load.spritesheet('_enemy_ork_three', 'images/_spd_ork_three.png', 87, 63);
    this.game.load.spritesheet('_enemy_ork_four', 'images/_spd_ork_four.png', 92, 63);
    this.game.load.spritesheet('_crocco', 'images/_spd_crocco.png', 80, 43);
    this.game.load.spritesheet('_bird', 'images/_spd_bird.png', 65, 50);
	
	// --> Game sound load
    this.game.load.audio('sfx:jump', 'sound/jump.ogg');
    this.game.load.audio('sfx:coin', 'sound/coin.ogg');
    this.game.load.audio('sfx:cherry', 'sound/cherry.ogg');
    this.game.load.audio('sfx:banana', 'sound/banana.ogg');
    this.game.load.audio('sfx:magic_kill', 'sound/magic_kill.ogg');
    this.game.load.audio('sfx:stomp', 'sound/diki_die.ogg');
    this.game.load.audio('sfx:attack', 'sound/diki_attack.ogg');
    this.game.load.audio('sfx:trophy', 'sound/trophy.ogg');
    this.game.load.audio('sfx:treasure', 'sound/treasure.ogg');
    this.game.load.audio('sfx:point_out', 'sound/next_level.ogg');
    this.game.load.audio('intro_sound', 'sound/intro_sound.ogg');
};

// --> Add Menu Option
PlayState.addMenuOption = function(text, callback) {
    var optionStyle = {
      font: '8pt Sniglet',
      fill: 'white',  // fill color
      align: 'right', // string: align, 'left'
      strokeThickness: 4  // stroke value
    };
	var txt = game.add.text(game.world.centerX -  -100, 25, text, optionStyle);
    txt.anchor.setTo(0.5);
    txt.stroke = "rgba(0,0,0,0)";
    txt.strokeThickness = 4;
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      txt.useHandCursor = true;
    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      txt.useHandCursor = false;
	  txt.input.useHandCursor = true; //hand cursor option
    };
    txt.inputEnabled = true;
    txt.events.onInputUp.add(callback, this);
    txt.events.onInputOver.add(onOver, this);
    txt.events.onInputOut.add(onOut, this);
    this.optionCount ++;
};

// --> Function design style button'menu option'
PlayState.makeIconBtn = function(x, y, text, optionStyle, callback){
    var txt = game.add.text(x,y , text, optionStyle);
      txt.anchor.setTo(0.5);
      txt.inputEnabled = true;
      txt.events.onInputUp.add(callback);
      txt.events.onInputOver.add(function (target) {
        console.log(fa_style.navitem.default)
        target.setStyle(fa_style.navitem.default);
      });
      txt.events.onInputOut.add(function (target) {
        target.setStyle(fa_style.navitem.hover);
      });
      txt.x = txt.x - txt.width/2
      txt.y = txt.y + txt.height/2
      return txt
};

// --> P.S - create function for audio'
PlayState.create = function () {
    // create sound entities
    this.sfx = {
        jump: this.game.add.audio('sfx:jump'), // sound jump
        coin: this.game.add.audio('sfx:coin'), // sound coin
        cherry: this.game.add.audio('sfx:cherry'), // sound cherry
        banana: this.game.add.audio('sfx:banana'), // sound banana
        magic_kill: this.game.add.audio('sfx:magic_kill'), // sound kill
        stomp: this.game.add.audio('sfx:stomp'), // sound stomp
        attack: this.game.add.audio('sfx:attack'), // sound attack
        trophy: this.game.add.audio('sfx:trophy'), // sound trophy
        treasure: this.game.add.audio('sfx:treasure'), // sound treasure
        point_out: this.game.add.audio('sfx:point_out'),  // sound point out
        level_sound: this.game.add.audio('sfx:level_sound'),  // sound level
    };

    // create level -- insert game fix images
    this.game.add.image(0, 0, 'background');
	
	// --> Level Design - create, add custom elements
	
	//level 1 -> custom design
	if (this.level == 0) {         
    this.game.add.image(375, 445, 'tree_pass_1');
	this.game.add.image(590, 445, 'tree_pass_2');
    };
	
	//level 2 -> custom design
	if (this.level == 1) {
	this.game.add.image(590, 445, 'tree_pass_2');
    };
	
	//level 3 -> custom design
	if (this.level == 2) {
	this.game.add.image(590, 445, 'tree_pass_2');
    };
	
	//level 4 -> custom design
	if (this.level == 3) {
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 302, 'tree_pass_2');
	this.game.add.image(375, 550, 'bush_pass_1');
	this.game.add.image(590, 550, 'bush_pass_1');
	this.game.add.image(285, 406, 'box_pass_1');
    };
	
	//level 5 -> custom design
	if (this.level == 4) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 302, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(375, 550, 'bush_pass_1');
	this.game.add.image(285, 406, 'box_pass_1');
    };
	
	//level 6 -> custom design
	if (this.level == 5) {
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 302, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(390, 406, 'box_pass_1');
    };
	
	//level 7 -> custom design
	if (this.level == 6) {	
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 321, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
    };
	
	//level 8 -> custom design
	if (this.level == 7) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 321, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
    };
	
	//level 9 -> custom design
	if (this.level == 8) {	
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 321, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
    };
	
	//level 10 -> custom design
	if (this.level == 9) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(790, 31, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(175, 445, 'tree_pass_1');
	this.game.add.image(355, 445, 'tree_pass_1');
	this.game.add.image(530, 445, 'tree_pass_2');
    };
	
	//level 11 -> custom design
	if (this.level == 10) {	
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(20, 300, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(175, 445, 'tree_pass_1');
	this.game.add.image(355, 445, 'tree_pass_1');
	this.game.add.image(530, 445, 'tree_pass_2');
	this.game.add.image(740, 31, 'tree_pass_2');
    };
	
	//level 12 -> custom design
	if (this.level == 11) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(20, 300, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(175, 445, 'tree_pass_1');
	this.game.add.image(355, 445, 'tree_pass_1');
	this.game.add.image(530, 445, 'tree_pass_2');
	this.game.add.image(740, 31, 'tree_pass_2');
    };
	
	//level 13 -> custom design
	if (this.level == 12) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(20, 300, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(175, 445, 'tree_pass_1');
	this.game.add.image(530, 445, 'tree_pass_2');
	this.game.add.image(740, 31, 'tree_pass_2');
    };
	
	//level 14 -> custom design
	if (this.level == 13) {		
	this.game.add.image(590, 200, 'tree_pass_1');
	this.game.add.image(20, 300, 'tree_pass_2');
	this.game.add.image(180, 80, 'tree_pass_2');
	this.game.add.image(175, 445, 'tree_pass_1');
	this.game.add.image(355, 445, 'tree_pass_1');
	this.game.add.image(530, 445, 'tree_pass_2');
	this.game.add.image(740, 31, 'tree_pass_2');
    };
    this._loadLevel(this.game.cache.getJSON(`level:${this.level}`));  //load json Level
	

    // crete hud with scoreboards
    this._createHud();            //base 'hud'
    this._createHudCherry();     //cherry 'hud'
    this._createHudBanana();    //banana 'hud'
    this._createHudTreasure(); //treasure 'hud'
	
    
	
	// --> sound level option
	this.stage.disableVisibilityChange = true;
	if (music.name !== "level_sound"  && gameOptions.playMusic) {
      music.stop();
      music = game.add.audio('level_sound');
      music.loop = true;
      music.play();
	  
    };
	
    // --> sound option game on/off
    game.stage.disableVisibilityChange = true;
	var playMusic = gameOptions.playMusic;
    this.addMenuOption(playMusic ? 'Sound On' : 'Sound Off', function (target) {
      playMusic = !playMusic;
      target.text = playMusic ? 'Sound On' : 'Sound Off';
      music.volume = playMusic ? 1 : 0;
    });
	 
	// --> sound option game button  sound on/off
    this.soundButton = this.game.add.button(this.game.world.centerX -  -45, 12,  'ctrl_tab_two', openWindow, this);
    
	this.soundButton.fixedToCamera = true;
    this.stage.disableVisibilityChange = false;
	//score text
    this.scoreText = game.make.text(game.world.centerX, 16, "Score: " + this.level, { font: '17pt Sniglet', fill: 'white', align: 'center', stroke: 'rgba(0,0,0,0)', srokeThickness: 4});
    this.scoreText.x = game.world.centerX - this.scoreText.width/2
    game.add.existing(this.scoreText);
    this.blurLayer = game.add.tileSprite(0, 0, game.world.width, game.world.height, 'blur-bg');
    this.blurLayer.alpha = 0;


    // --> pause function
	function dikiPause() {
    game.paused = ( game.paused) ? false : true;
    }
	
	// --> key pause
	this.keys.p.onDown.add(function () {
	dikiPause();
    }, this);
		

// --> Additional Custom Design 'Difficulty Level'

//level 6 ->  additional custom design - difficulty level
if (this.level == 5) {
    this.game.add.image(300, 185, 'bush_pass_1');
	this.game.add.image(213, 185, 'bush_pass_1');
	this.game.add.image(123, 185, 'bush_pass_1');
	this.game.add.image(475, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(650, 305, 'bush_pass_1');
	this.game.add.image(590, 550, 'bush_pass_1');
	this.game.add.image(510, 550, 'bush_pass_1');
	this.game.add.image(430, 550, 'bush_pass_1');
	this.game.add.image(350, 550, 'bush_pass_1');
	this.game.add.image(270, 550, 'bush_pass_1');
	this.game.add.image(190, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(20, 550, 'bush_pass_1');
};

//level 7 ->  additional custom design - difficulty level
if (this.level == 6) {
    this.game.add.image(300, 185, 'bush_pass_1');
	this.game.add.image(213, 185, 'bush_pass_1');
	this.game.add.image(123, 185, 'bush_pass_1');
	this.game.add.image(475, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(650, 305, 'bush_pass_1');
	this.game.add.image(590, 550, 'bush_pass_1');
	this.game.add.image(510, 550, 'bush_pass_1');
	this.game.add.image(430, 550, 'bush_pass_1');
	this.game.add.image(350, 550, 'bush_pass_1');
	this.game.add.image(270, 550, 'bush_pass_1');
	this.game.add.image(190, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(20, 550, 'bush_pass_1');
};

//level 8 ->  additional custom design - difficulty level
if (this.level == 7) {
    this.game.add.image(280, 185, 'bush_pass_1');
	this.game.add.image(210, 185, 'bush_pass_1');
	this.game.add.image(140, 185, 'bush_pass_1');
	this.game.add.image(493, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(635, 305, 'bush_pass_1');
	this.game.add.image(600, 550, 'bush_pass_1');
	this.game.add.image(530, 550, 'bush_pass_1');
	this.game.add.image(460, 550, 'bush_pass_1');
	this.game.add.image(390, 550, 'bush_pass_1');
	this.game.add.image(320, 550, 'bush_pass_1');
	this.game.add.image(250, 550, 'bush_pass_1');
	this.game.add.image(180, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(40, 550, 'bush_pass_1');
};
		
//level 9 ->  additional custom design - difficulty level	
if (this.level == 8) {
    this.game.add.image(280, 185, 'bush_pass_1');
	this.game.add.image(210, 185, 'bush_pass_1');
	this.game.add.image(140, 185, 'bush_pass_1');
	this.game.add.image(493, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(635, 305, 'bush_pass_1');
	this.game.add.image(600, 550, 'bush_pass_1');
	this.game.add.image(530, 550, 'bush_pass_1');
	this.game.add.image(460, 550, 'bush_pass_1');
	this.game.add.image(390, 550, 'bush_pass_1');
	this.game.add.image(320, 550, 'bush_pass_1');
	this.game.add.image(250, 550, 'bush_pass_1');
	this.game.add.image(180, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(40, 550, 'bush_pass_1');
};

//level 10 ->  additional custom design - difficulty level
if (this.level == 9) {
    this.game.add.image(280, 185, 'bush_pass_1');
	this.game.add.image(210, 185, 'bush_pass_1');
	this.game.add.image(140, 185, 'bush_pass_1');
	this.game.add.image(493, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(635, 305, 'bush_pass_1');
	this.game.add.image(600, 550, 'bush_pass_1');
	this.game.add.image(530, 550, 'bush_pass_1');
	this.game.add.image(460, 550, 'bush_pass_1');
	this.game.add.image(390, 550, 'bush_pass_1');
	this.game.add.image(320, 550, 'bush_pass_1');
	this.game.add.image(250, 550, 'bush_pass_1');
	this.game.add.image(180, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(40, 550, 'bush_pass_1');
};

//level 11 ->  additional custom design - difficulty level
if (this.level == 10) {
    this.game.add.image(280, 185, 'bush_pass_1');
	this.game.add.image(210, 185, 'bush_pass_1');
	this.game.add.image(140, 185, 'bush_pass_1');
	this.game.add.image(493, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(635, 305, 'bush_pass_1');
	this.game.add.image(481, 55, 'bush_pass_1');
	this.game.add.image(551, 55, 'bush_pass_1');
	this.game.add.image(622, 55, 'bush_pass_1');
	this.game.add.image(600, 550, 'bush_pass_1');
	this.game.add.image(530, 550, 'bush_pass_1');
	this.game.add.image(460, 550, 'bush_pass_1');
	this.game.add.image(390, 550, 'bush_pass_1');
	this.game.add.image(320, 550, 'bush_pass_1');
	this.game.add.image(250, 550, 'bush_pass_1');
	this.game.add.image(180, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(40, 550, 'bush_pass_1');
};	

//level 12 ->  additional custom design - difficulty level
if (this.level == 11) {
    this.game.add.image(280, 185, 'bush_pass_1');
	this.game.add.image(210, 185, 'bush_pass_1');
	this.game.add.image(140, 185, 'bush_pass_1');
	this.game.add.image(493, 305, 'bush_pass_1');
	this.game.add.image(563, 305, 'bush_pass_1');
	this.game.add.image(635, 305, 'bush_pass_1');
	this.game.add.image(481, 55, 'bush_pass_1');
	this.game.add.image(551, 55, 'bush_pass_1');
	this.game.add.image(622, 55, 'bush_pass_1');
	this.game.add.image(810, 425, 'bush_pass_1');
	this.game.add.image(763, 427, 'box_pass_1');
	this.game.add.image(600, 550, 'bush_pass_1');
	this.game.add.image(530, 550, 'bush_pass_1');
	this.game.add.image(460, 550, 'bush_pass_1');
	this.game.add.image(390, 550, 'bush_pass_1');
	this.game.add.image(320, 550, 'bush_pass_1');
	this.game.add.image(250, 550, 'bush_pass_1');
	this.game.add.image(180, 550, 'bush_pass_1');
	this.game.add.image(110, 550, 'bush_pass_1');
	this.game.add.image(40, 550, 'bush_pass_1');
};		
	
//level 13 ->  additional custom design - difficulty level
if (this.level == 12) {
	this.game.add.image(338, 186, 'box_pass_1');
	this.game.add.image(288, 186, 'box_pass_1');
    this.game.add.image(238, 186, 'box_pass_1');
	this.game.add.image(188, 186, 'box_pass_1');
	this.game.add.image(138, 186, 'box_pass_1');
	this.game.add.image(490, 306, 'box_pass_1');
	this.game.add.image(540, 306, 'box_pass_1');
	this.game.add.image(590, 306, 'box_pass_1');
	this.game.add.image(640, 306, 'box_pass_1');
	this.game.add.image(690, 306, 'box_pass_1');
	this.game.add.image(667, 56, 'box_pass_1');
	this.game.add.image(617, 56, 'box_pass_1');
    this.game.add.image(567, 56, 'box_pass_1');
	this.game.add.image(517, 56, 'box_pass_1');
	this.game.add.image(467, 56, 'box_pass_1');
	this.game.add.image(810, 425, 'bush_pass_1');
	this.game.add.image(763, 427, 'box_pass_1');
	this.game.add.image(625, 552, 'box_pass_1');
	this.game.add.image(575, 552, 'box_pass_1');
	this.game.add.image(525, 552, 'box_pass_1');
	this.game.add.image(475, 552, 'box_pass_1');
	this.game.add.image(525, 552, 'box_pass_1');
	this.game.add.image(475, 552, 'box_pass_1');
	this.game.add.image(425, 552, 'box_pass_1');
	this.game.add.image(375, 552, 'box_pass_1');
	this.game.add.image(325, 552, 'box_pass_1');
	this.game.add.image(275, 552, 'box_pass_1');
	this.game.add.image(225, 552, 'box_pass_1');
	this.game.add.image(175, 552, 'box_pass_1');
	this.game.add.image(125, 552, 'box_pass_1');
	this.game.add.image(75, 552, 'box_pass_1');
	this.game.add.image(25, 552, 'box_pass_1');
    };	
		
//level 14 ->  additional custom design - difficulty level	
if (this.level == 13) {
	this.game.add.image(332, 187, 'box_pass_1');
	this.game.add.image(289, 187, 'box_pass_1');
    this.game.add.image(246, 187, 'box_pass_1');
	this.game.add.image(203, 187, 'box_pass_1');
	this.game.add.image(160, 187, 'box_pass_1');
	this.game.add.image(684, 307, 'box_pass_1');
	this.game.add.image(641, 307, 'box_pass_1');
	this.game.add.image(598, 307, 'box_pass_1');
    this.game.add.image(555, 307, 'box_pass_1');
	this.game.add.image(512, 307, 'box_pass_1');
	this.game.add.image(469, 307, 'box_pass_1');
	this.game.add.image(674, 57, 'box_pass_1');
	this.game.add.image(631, 57, 'box_pass_1');
	this.game.add.image(588, 57, 'box_pass_1');
    this.game.add.image(545, 57, 'box_pass_1');
	this.game.add.image(502, 57, 'box_pass_1');
	this.game.add.image(459, 57, 'box_pass_1');
	this.game.add.image(892, 427, 'box_pass_1');
	this.game.add.image(849, 427, 'box_pass_1');
	this.game.add.image(806, 427, 'box_pass_1');
	this.game.add.image(762, 427, 'box_pass_1');
	this.game.add.image(619, 552, 'box_pass_1');
	this.game.add.image(576, 552, 'box_pass_1');
	this.game.add.image(533, 552, 'box_pass_1');
	this.game.add.image(491, 552, 'box_pass_1');
	this.game.add.image(448, 552, 'box_pass_1');
	this.game.add.image(405, 552, 'box_pass_1');
	this.game.add.image(362, 552, 'box_pass_1');
	this.game.add.image(319, 552, 'box_pass_1');
	this.game.add.image(276, 552, 'box_pass_1');
	this.game.add.image(234, 552, 'box_pass_1');
	this.game.add.image(191, 552, 'box_pass_1');
	this.game.add.image(148, 552, 'box_pass_1');
	this.game.add.image(105, 552, 'box_pass_1');
	this.game.add.image(63, 552, 'box_pass_1');
	this.game.add.image(20, 552, 'box_pass_1');
};

   var button;
   var popup;
   var tween = null;  
    button = game.add.button(game.world.centerX - 77, 12, 'ctrl_tab_one', openWindow, this);
    button.input.useHandCursor = true;
    //  You can drag the pop-up window around
    popup = game.add.sprite(game.world.centerX, game.world.centerY, 'diki_control_tab');
    popup.alpha = 0.8;
    popup.anchor.set(0.5);
    popup.inputEnabled = true;
    popup.input.enableDrag();

    //  Position the close button to the top-right of the popup sprite (minus 8px for spacing)
    var pw = (popup.width / 2) - 30;
    var ph = (popup.height / 2) - 8;

    //  And click the close button to close it down again
    var closeButton = game.make.sprite(pw, -ph, 'close');
    closeButton.inputEnabled = true;
    closeButton.input.priorityID = 1;
    closeButton.input.useHandCursor = true;
    closeButton.events.onInputDown.add(closeWindow, this);
	

    // Add the "close button" to the popup window image
    popup.addChild(closeButton);

    // Hide it awaiting a click
    popup.scale.set(0.000001);

function openWindow() {
    if ((tween !== null && tween.isRunning) || popup.scale.x === 1)
    {
        return;
    }
    
    // Create a tween that will pop-open the window, but only if it's not already tweening or open
    tween = game.add.tween(popup.scale).to( { x: 1, y: 1 }, 1000, Phaser.Easing.Elastic.Out, true);
};

function closeWindow() {
    if (tween && tween.isRunning || popup.scale.x === 0.1)
    {
        return;
    }
    //  Create a tween that will close the window, but only if it's not already tweening or closed
    tween = game.add.tween(popup.scale).to( { x: 0.000001, y: 0.000001}, 500, Phaser.Easing.Elastic.In, true);
};

};


/* 5. PS - Update
==========================================*/

PlayState.update = function () {
    this._handleCollisions();
    this._handleInput();
    this.coinFont.text = `x${this.coinPickupCount}`;
    this.cherryFont.text = `x${this.cherryPickupCount}`;
    this.bananaFont.text = `x${this.bananaPickupCount}`;
    this.trophyIcon.frame = this.hasTrophy ? 1 : 0;
    this.treasureIcon.frame = this.hasTreasure ? 1 : 0;
    this.score += 0.05;
    this.scoreText.setText( "World:  " + (this.level + 1)); // Top text World + number level
    this.scoreText.x = (game.world.centerX - this.scoreText.width/2);

  
};

/* 6. PS -> Collision
==========================================*/

PlayState._handleCollisions = function () {
    this.game.physics.arcade.collide(this.ork_mode_one, this.platforms);
    this.game.physics.arcade.collide(this.ork_mode_one, this.enemyWalls);
    this.game.physics.arcade.collide(this.ork_mode_two, this.platforms);
    this.game.physics.arcade.collide(this.ork_mode_two, this.enemyWalls);
    this.game.physics.arcade.collide(this.ork_mode_three, this.platforms);
    this.game.physics.arcade.collide(this.ork_mode_three, this.enemyWalls);
    this.game.physics.arcade.collide(this.ork_mode_four, this.platforms);
    this.game.physics.arcade.collide(this.ork_mode_four, this.enemyWalls);
    this.game.physics.arcade.collide(this.crocco_mode, this.platforms);
    this.game.physics.arcade.collide(this.crocco_mode, this.enemyWalls);
    this.game.physics.arcade.collide(this.bird_mode, this.platforms);
    this.game.physics.arcade.collide(this.bird_mode, this.enemyWalls);
    this.game.physics.arcade.collide(this.diki, this.platforms);
    this.game.physics.arcade.overlap(this.diki, this.cherry, this._onDiki_KongVsCherry,
        null, this);
    this.game.physics.arcade.overlap(this.diki, this.banana, this._onDiki_KongVsBanana,
        null, this);
    this.game.physics.arcade.overlap(this.diki, this.coins, this._onDiki_KongVsCoin,
        null, this);
    this.game.physics.arcade.overlap(this.diki, this.ork_mode_one,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.ork_mode_two,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.ork_mode_three,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.ork_mode_four,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.crocco_mode,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.bird_mode,
        this._onDiki_KongVsEnemy, null, this);
    this.game.physics.arcade.overlap(this.diki, this.trophy, this._onDiki_KongVsTrophy,
        null, this);
    this.game.physics.arcade.overlap(this.diki, this.treasure, this._onDiki_KongVsTreasure,
        null, this);
    this.game.physics.arcade.overlap(this.diki, this.point_out, this._onDiki_KongVsPoint_out,
        // ignore if there is no key or the player is on air
        function (diki, point_out) {
            return this.hasTrophy && diki.body.touching.down;
        }, this);
};

/* 7. PS -> handle Input character 'diki'
==========================================*/
PlayState._handleInput = function () {
	
    if (this.keys.left.isDown) { // move diki left
        this.diki.move(-1);   
    }
    else if (this.keys.right.isDown) { // move diki right
        this.diki.move(1);    
    }
    else { // stop
        this.diki.move(0);  
    }	
};

/* 8. PS -> Load level
==========================================*/

PlayState._loadLevel = function (data) {
	this.menuGroup = this.game.add.group();
    this.bgDecoration = this.game.add.group();
    this.platforms = this.game.add.group();
    this.coins = this.game.add.group();
    this.cherry = this.game.add.group();
    this.banana = this.game.add.group();
    this.ork_mode_one = this.game.add.group();
    this.ork_mode_two = this.game.add.group();
    this.ork_mode_three = this.game.add.group();
    this.ork_mode_four = this.game.add.group();
    this.crocco_mode = this.game.add.group();
    this.bird_mode = this.game.add.group();
    this.enemyWalls = this.game.add.group();
    this.enemyWalls.visible = false;
    data.platforms.forEach(this._spawnPlatform, this);
	// --> spawn diki and enemies
    this._spawnCharacters_ork_one({diki: data.diki, ork_mode_one: data.ork_mode_one});
    this._spawnCharacters_ork_two({diki: data.diki, ork_mode_two: data.ork_mode_two});
    this._spawnCharacters_ork_three({diki: data.diki, ork_mode_three: data.ork_mode_three});
    this._spawnCharacters_ork_four({diki: data.diki, ork_mode_four: data.ork_mode_four});
    this._spawnCharacters_crocco({diki: data.diki, crocco_mode: data.crocco_mode});
    this._spawnCharacters_bird({diki: data.diki, bird_mode: data.bird_mode});
    // --> spawn important objects
    data.coins.forEach(this._spawnCoin, this);
    data.cherry.forEach(this._spawnCherry, this);
    data.banana.forEach(this._spawnBanana, this);
    this._spawnPoint_out(data.point_out.x, data.point_out.y);
    this._spawnAccess_dir(data.access_dir.x, data.access_dir.y);
    this._spawnOut_dir(data.out_dir.x, data.out_dir.y);
    this._spawnTrophy(data.trophy.x, data.trophy.y);
    this._spawnTreasure(data.treasure.x, data.treasure.y);
	
    // --> enable gravity
    const GRAVITY = 1200;
    this.game.physics.arcade.gravity.y = GRAVITY;
};


/* 9. PS -> spawn platform function
==========================================*/

PlayState._spawnPlatform = function (platform) {
    let sprite = this.platforms.create(
        platform.x, platform.y, platform.image);
    this.game.physics.enable(sprite);
    sprite.body.allowGravity = false;
    sprite.body.immovable = true;
    
    this._spawnEnemyWall(platform.x, platform.y, 'left');
    this._spawnEnemyWall(platform.x + sprite.width, platform.y, 'right');
    
};


/* 10. PS -> spawn enemy wall
==========================================*/
PlayState._spawnEnemyWall = function (x, y, side) {
    let sprite = this.enemyWalls.create(x, y, 'invisible-wall');
    // anchor and y displacement
    sprite.anchor.set(side === 'left' ? 1 : 0, 1);
    // physic properties
    this.game.physics.enable(sprite);
    sprite.body.immovable = true;
    sprite.body.allowGravity = false;  
};

/* 11. PS -> spawn all characters
==========================================*/

     // --> PS: ork one character
PlayState._spawnCharacters_ork_one = function (data) {
    // --> spawn ork one
    data.ork_mode_one.forEach(function (_enemy_ork_one) {
        let sprite = new orky_one(this.game, _enemy_ork_one.x, _enemy_ork_one.y);
        this.ork_mode_one.add(sprite);
        
    }, this);
	
    // --> spawn diki
    this.diki = new Diki_Kong(this.game, data.diki.x, data.diki.y);
    this.game.add.existing(this.diki);
};

    // --> PS: ork two character
PlayState._spawnCharacters_ork_two = function (data) {
    // --> spawn ork two
    data.ork_mode_two.forEach(function (_enemy_ork_two) {
        let sprite = new orky_two(this.game, _enemy_ork_two.x, _enemy_ork_two.y);
        this.ork_mode_two.add(sprite);
        
    }, this);

};
     // --> PS: ork three character
PlayState._spawnCharacters_ork_three = function (data) {
    // --> spawn ork three
    data.ork_mode_three.forEach(function (_enemy_ork_three) {
        let sprite = new orky_three(this.game, _enemy_ork_three.x, _enemy_ork_three.y);
        this.ork_mode_three.add(sprite);
    }, this);

};

     // --> PS: ork four character
PlayState._spawnCharacters_ork_four = function (data) {
    // --> spawn ork four
    data.ork_mode_four.forEach(function (_enemy_ork_four) {
        let sprite = new orky_four(this.game, _enemy_ork_four.x, _enemy_ork_four.y);
        this.ork_mode_four.add(sprite);
    }, this);

};

     // --> PS: crocco character
PlayState._spawnCharacters_crocco = function (data) {
    // --> spawn crocco
    data.crocco_mode.forEach(function (_crocco) {
        let sprite = new crocco(this.game, _crocco.x, _crocco.y);
        this.crocco_mode.add(sprite);
    }, this);


};
    // --> PS: bird character
PlayState._spawnCharacters_bird = function (data) {
    // --> spawn bird
    data.bird_mode.forEach(function (_bird) {
        let sprite = new bird(this.game, _bird.x, _bird.y);
        this.bird_mode.add(sprite);
		sprite.body.allowGravity = false;
    }, this);
};

     // --> PS: spawn coin function
PlayState._spawnCoin = function (coin) {
    let sprite = this.coins.create(coin.x, coin.y, 'coin');
    sprite.anchor.set(0.5, 0.5);
    this.game.physics.enable(sprite);
    sprite.body.allowGravity = false;
};

    // --> PS: spawn cherry function
PlayState._spawnCherry = function (cherry) {
    let sprite = this.cherry.create(cherry.x, cherry.y, 'cherry');
    sprite.anchor.set(0.5, 0.5);
    this.game.physics.enable(sprite);
    sprite.body.allowGravity = false;
};

   // --> PS: spawn banana function
PlayState._spawnBanana = function (banana) {
    let sprite = this.banana.create(banana.x, banana.y, 'banana');
    sprite.anchor.set(0.5, 0.5);
    this.game.physics.enable(sprite);
    sprite.body.allowGravity = false;
};

   // --> PS: spawn point out function
PlayState._spawnPoint_out = function (x, y) {
    this.point_out = this.bgDecoration.create(x, y, 'point_out');
    this.point_out.anchor.setTo(0.5, 1);
    this.game.physics.enable(this.point_out);
    this.point_out.body.allowGravity = false;
};

  // --> PS: spawn access direction function
PlayState._spawnAccess_dir = function (x, y) {
    this.access_dir = this.bgDecoration.create(x, y, 'access_dir');
    this.game.physics.enable(this.access_dir);
    this.access_dir.body.allowGravity = false; 
};

  // --> PS: spawn out dir function
PlayState._spawnOut_dir = function (x, y) {
    this.out_dir = this.bgDecoration.create(x, y, 'out_dir');
	this.game.physics.enable(this.out_dir);
	this.out_dir.body.allowGravity = false;
};

  // --> PS: spawn trophy function
PlayState._spawnTrophy = function (x, y) {
    this.trophy = this.bgDecoration.create(x, y, 'trophy');
    // --> enable physics to detect collisions, so the diki can pick the key up
    this.game.physics.enable(this.trophy);
    this.trophy.body.allowGravity = false;
    // --> add a small 'up & down' animation via a tween
    this.game.add.tween(this.trophy)
        .yoyo(true)
        .loop()
        .start();
};

    // --> PS: spawn treasure function
PlayState._spawnTreasure = function (x, y) {
    this.treasure = this.bgDecoration.create(x, y, 'treasure');
    //--> enable physics to detect collisions, so the diki can pick the key up
    this.game.physics.enable(this.treasure);
    this.treasure.body.allowGravity = false;
    // --> add a small 'up & down' animation via a tween
    this.game.add.tween(this.treasure)
        .yoyo(true)
        .loop()
        .start();
};

  // --> PS: diki - coin function
PlayState._onDiki_KongVsCoin = function (diki, coin) {
    this.sfx.coin.play();
    coin.kill();
    this.coinPickupCount++;
  // --> condition treasure number coin
   if (this.coinPickupCount > 8) {
      this.hasTreasure = true;
    }
	
  // --> level 4 condition coin - treasure
	if (this.level == 4) 
	{	
    if (this.coinPickupCount > 6) 
	{
      this.hasTreasure = true;
    }
    }
 // --> level 5 condition coin - treasure
	if (this.level == 5) 
	{	
    if (this.coinPickupCount > 6) 
	{
      this.hasTreasure = true;
    }
    }	
};

  // --> PS: diki - cherry function
PlayState._onDiki_KongVsCherry = function (diki, cherry) {
    this.sfx.cherry.play();
    cherry.kill();
    this.cherryPickupCount++;
 // --> condition treasure number cherry
    if (this.cherryPickupCount++ > 8) {
      this.hasTreasure = true;
  
    }
 // --> level 7 condition cherry - treasure
	if (this.level == 6) 
	{	
    if (this.cherryPickupCount > 2) 
	{
      this.hasTreasure = true;
    }
    }
 // --> level 8 condition cherry - treasure
	if (this.level == 7) 
	{	
    if (this.cherryPickupCount > 2) 
	{
      this.hasTreasure = true;
    }
    }
	
 // --> level 9 condition cherry - treasure
	if (this.level == 8) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }
 // --> level 10 condition cherry - treasure	
	if (this.level == 9) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }
	
 // --> level 11 condition cherry - treasure
	if (this.level == 10) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }
	
 // --> level 12 condition cherry - treasure	
	if (this.level == 11) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }
	
 // --> level 13 condition cherry - treasure
	if (this.level == 12) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }

 // --> level 14 condition cherry - treasure
	if (this.level == 13) 
	{	
    if (this.cherryPickupCount > 5) 
	{
      this.hasTreasure = true;
    }
    }
};

 // --> PS: diki - trophy function
PlayState._onDiki_KongVsTrophy = function (diki, trophy) {
    this.sfx.trophy.play();
    trophy.kill();
    this.hasTrophy = true;
	if (this.hasTrophy == true) {

    }
};

// --> PS: diki - banana function
PlayState._onDiki_KongVsBanana = function (diki, banana) {
    this.sfx.banana.play();
    banana.kill();
    this.bananaPickupCount++;
	
    // --> condition banana number trophy
    if (this.bananaPickupCount > 3) 
	{
      this.hasTrophy = true;
    }
	
  // --> level 4 condition banana - treasure
	if (this.level == 4) 
	{	
     if (this.bananaPickupCount > 1) 
	 {
      this.hasTreasure = true;
     }
	}
	 
  // --> level 5 condition banana - treasure
	if (this.level == 5) 
	{	
     if (this.bananaPickupCount > 1) 
	 {
      this.hasTreasure = true;
     }
    }
};

// --> PS: diki - treasure function
PlayState._onDiki_KongVsTreasure = function (diki, treasure) {
    this.sfx.treasure.play();
    treasure.kill(); // treasure - gone
	this.hasTreasure = true;
	if (this.hasTreasure == true) {

    }
};

// --> PS: diki - enemy function
PlayState._onDiki_KongVsEnemy = function (diki, enemy) {
	if (this.hasTreasure > 0) {
    enemy.die(); // enemy die
    this.sfx.magic_kill.play();
    }
    else if (diki.body.velocity.y > 0) {
		
        diki.bounce();
        enemy.die();
        this.sfx.attack.play(); // sound attack
    }
    else {
	    this.sfx.stomp.play();
        this.game.state.start("GameOver");
	}
};

// --> PS: diki - point out function
PlayState._onDiki_KongVsPoint_out = function (diki, point_out) {
    this.sfx.point_out.play(); //sound finish world (level)
    this.game.state.restart(true, false, { level: this.level + 1});   
};

 /* 12. PS: Hud aria function
==========================================*/
PlayState._createHud = function () {
    const NUMBERS_STR = '0123456789X';
    this.coinFont = this.game.add.retroFont('font:numbers', 20, 26,
    NUMBERS_STR);
    this.trophyIcon = this.game.make.image(317, 20, 'icon:trophy');
    this.trophyIcon.anchor.set(0, 0.5);
	let coinIcon = this.game.make.image(this.trophyIcon.width + 180, 0, 'icon:coin');
    let coinScoreImg = this.game.make.image(coinIcon.x + coinIcon.width,
    coinIcon.height / 2, this.coinFont);
    coinScoreImg.anchor.set(0, 0.5);
    this.hud = this.game.add.group();
    this.hud.add(coinIcon);
    this.hud.add(coinScoreImg);
    this.hud.add(this.trophyIcon);
    this.hud.position.set(10, 10);
    
};

// --> PS: hud treasure function
PlayState._createHudTreasure = function () {
    this.treasureIcon = this.game.make.image(350, 20, 'icon:treasure'); // icon treasuse
    this.treasureIcon.anchor.set(0, 0.5);
    this.hud = this.game.add.group();
    this.hud.add(this.treasureIcon);
    this.hud.position.set(10, 10);   
};

// --> PS: hud cherry function
PlayState._createHudCherry = function () {
    const NUMBERS_STR = '0123456789X ';
    this.cherryFont = this.game.add.retroFont('font:numbers', 20, 26,
    NUMBERS_STR);
    this.keyIconCherry = this.game.make.image(485, 279, 'icon:cherry'); 
    this.keyIconCherry.anchor.set(0, 0.5);
    let cherryIcon = this.game.make.image(this.keyIconCherry.width + -25, 0, 'icon:cherry');
    let cherryScoreImg = this.game.make.image(cherryIcon.x + cherryIcon.width,
    cherryIcon.height / 2, this.cherryFont);
    cherryScoreImg.anchor.set(0, 0.5);
    this.hud.add(cherryIcon);
    this.hud.add(cherryScoreImg);
    this.hud.position.set(10, 10);
};

// --> PS: hud banana function
PlayState._createHudBanana = function () {
    const NUMBERS_STR = '0123456789X ';
    this.bananaFont = this.game.add.retroFont('font:numbers', 20, 26,
    NUMBERS_STR);
    this.keyIconBanana = this.game.make.image(480, 279, 'icon:banana'); // icon banana
    this.keyIconBanana.anchor.set(0, 0.5);
    let bananaIcon = this.game.make.image(this.keyIconBanana.width + 72, 0, 'icon:banana');
    let bananaScoreImg = this.game.make.image(bananaIcon.x + bananaIcon.width,
    bananaIcon.height / 2, this.bananaFont);
    bananaScoreImg.anchor.set(0, 0.5);
    this.hud.add(bananaIcon);
    this.hud.add(bananaScoreImg);
    this.hud.position.set(10, 10);
	
};

 /* 13. Start game function
==========================================*/
// --> diki kong run all PlayState functions by 'game_play'
var diki_kong = function() {
	window.onload = function () {
    game.state.add('game_play', PlayState);
    game.state.start('game_play', true, false, {level: 0}); // --> run game - level:0
    }, this 
};
var startx = PlayState.create();
