 /* Main file
 =============*/

'use strict';

// --> Global Variables Phaser
var game = new Phaser.Game(950, 630, Phaser.AUTO, 'game'),
  Main = function () {},
  gameOptions = {
    playSound: true,    //game option play sound
    playMusic: true,   //game option play music
  },
  music,
  WebFontConfig;

// --> prelod function full images
Main.prototype = {
  preload: function () {
    game.load.image('loading',  'images/menu/loading.png'); // load loading
    game.load.image('brand',    'images/menu/logo.png'); // load brand
	game.load.image('logo_dev',    'images/menu/logo_dev.png'); // load logo_dev
	game.load.image('loader', 'images/menu/loader.png');       // load loader
	game.load.image('loader_min_r', 'images/menu/loader_min.png');  // load  loader min right 
	game.load.image('loader_min_l', 'images/menu/loader_min.png'); // load  loader  min left
	game.load.image('start_ground',    'images/menu/_diki_start_ground.png');     //  load start ground
	game.load.image('credit_ground',    'images/menu/_diki_credit_ground.png');   // load credit ground
	game.load.image('replay_ground',    'images/menu/_diki_replay_ground.png');  // load replay ground
	game.load.image('flower',    'images/menu/flower_rotate.png');           // load flower
	game.load.image('play_button',    'images/menu/_diki_play_button.png');  // load play button
	game.load.image('replay_button',    'images/menu/_diki_replay_button.png');   // load replay button
	game.load.image('setting_button',    'images/menu/_diki_setting_button.png'); // load setting button
	game.load.image('credit_button',    'images/menu/_diki_credit_button.png');  // load credit button 
	game.load.image('sound_button_on',    'images/menu/_diki_sound_button_on.png'); // load sound button on
	game.load.image('sound_button_off',    'images/menu/_diki_sound_button_off.png'); // load sound button off
	game.load.image('sound_button_clean',    'images/menu/_diki_clean_button.png');  // load sound button clean
	game.load.image('back_button',    'images/menu/_diki_back_button.png'); // load back button
	game.load.image('button-pause',    'images/menu/button-pause.png'); // load button pause
	
	// --> load spritesheet
	game.load.spritesheet('sound_button', 'images/menu/button-audio.png', 50, 50); // load  sound button
	
	// --> load script
    game.load.script('polyfill',   'js/library/polyfill.js');
    game.load.script('utils',   'js/library/utils.js');
    game.load.script('splash',  'js/script/splash.js');
	
  },

  create: function () {
    game.state.add('Splash', Splash); // add Splash file and variable
    game.state.start('Splash');      // start Splash
  }
};
game.state.add('Main', Main);      // add state Main
game.state.start('Main');          // add(run) Main
