//Diki Kong Banana Hero Dk - Assignment
document.writeln("<script type='text/javascript' src='./js/phaser.min.js'></script>");




function myFunction(){
    var diki_monky_adv = this.game;
};