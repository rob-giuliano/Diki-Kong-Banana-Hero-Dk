 /* Style file
 ================*/
'use strict';

var style;
var cs = {}; // for color scheme - humm could also good with css... but oh well

// --> this is a wrapped function
(function () {
	
  // --> the variables declared here will not be scoped anywhere and will only be accessible in this wrapped function
  var defaultColor = "white", // default color
    highlightColor = "#FEFFD5"; // high light color
  // --> Color Scheme
  cs.heading_color = "#E6E2AF"; // color heading
  cs.background_color = "#B8FBF8"; // color background
  cs.text_color = "#fff"; //text color
  cs.accent_color = "#fff"; // accent color
  cs.accent_hover_color = "#fff";  // accent hover color
  cs.fa_text_color = cs.accent_color; // text color

  // --> Style base
  style = {
    navitem: {
      base: {
        font: '30pt Sniglet', // font style option
        align: 'left',
        srokeThickness: 4 // stroke value
      },
      default: {
        fill: cs.text_color,
        stroke: 'rgba(0,0,0,0)'
      },
      inverse: {
        fill: cs.accent_color,
        stroke: cs.accent_color  // stroke accent_color
      },
      hover: {
        fill: cs.accent_color,
        stroke: 'rgba(200,200,200,0.5)'
      }
    },
  };
  
  // --> fa style 'button'
  fa_style = {
    btn:{
      pause:{
        fill : cs.accent_color,
        font : '21px FontAwesome', // font style option
      },
    },
    navitem: {
      base: {
        font: '21px FontAwesome',  // font style option
        align: 'left',
        srokeThickness: 0 // stroke value
      },
      default: {
        fill: cs.fa_text_color,
        stroke: 'rgba(0,0,0,0)'
      },
      inverse: {
        fill: cs.accent_hover_color,
        stroke: cs.accent_color // stroke accent_color
      },
      hover: {
        fill: cs.accent_color,
        stroke: 'rgba(100,100,100,0.5)'
      },
      randomCustom:{
        font: "21px FontAwesome", // font style option
        align: 'right', // string: select  align, 'left' or 'right'
        srokeThickness: 10, // stroke Thickness value
        fill: '#fff',   // fill color
        stroke: "#fff", // stroke color
        "-ms-transform": 'translate(50px,100px)', /* IE 9 */
        "-webkit-transform": 'translate(50px,100px)', /* Safari */
        "transform": 'translate(50px,100px)',
      }
    },

  };

  // -->fa stayle function
  fa_style.overrideOnly = function (_styleObj, newStyle) {
    Object.assign(_styleObj, newStyle)
  }

  for (var key in style.navitem) { // variable key(value)  in style
    if (key !== "base") {
      Object.assign(style.navitem[key], style.navitem.base)
    }
  }

  for (var key in fa_style.navitem) { // variable key(value)  for fa_style
    if (key !== "base") {
      Object.assign(fa_style.navitem[key], fa_style.navitem.base)
    }
  }
})
();  // the trailing () triggers the function call immediately
