 /* GameOver file
 ================*/
 
'use strict';

// --> GameOver variable
  var GameOver = function(game) {};
  GameOver.prototype = {
  preload: function () {
    this.optionCount = 1;
  },

  // --> add menu option - group
  addMenuOption: function(text, callback, group) {
    var optionStyle = {
      font: '30pt Modak',
      fill: cs.heading_color,
      align: 'left',
      stroke: 'rgba(0,0,0,0)',
      srokeThickness: 4
    };
	
	// --> var 'txt' menu option - group
    var txt = game.add.text(game.world.centerX, (this.optionCount * 80) + 300, text, optionStyle);
    txt.anchor.setTo(0.5);
    txt.stroke = "rgba(0,0,0,0";
    txt.strokeThickness = 4;
    var onOver = function (target) {
      target.fill = cs.accent_hover_color;
      target.stroke = "rgba(200,200,200,0.5)";
      txt.useHandCursor = true;
    };
    var onOut = function (target) {
      target.fill = cs.accent_color;
      target.stroke = "rgba(0,0,0,0)";
      txt.useHandCursor = false;
    };
    txt.inputEnabled = true;
    txt.events.onInputUp.add(callback, this);
    txt.events.onInputOver.add(onOver, this);
    txt.events.onInputOut.add(onOut, this);
	
	// --> var 'txt' count
    this.optionCount ++;
    if (group) {
      group.add(txt)
    }
  },
  
    // --> menu option - 'replay button' align
  addMenuOption5: function(button_replay,  callback) {
	var button_replay = this.add.sprite(game.world.centerX-(45), 450,'replay_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      button_replay.useHandCursor = true;  //hand cursor option
    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      button_replay.useHandCursor = true; //hand cursor option

    };
	
    button_replay.inputEnabled = true;
	button_replay.useHandCursor = true;
	button_replay.input.useHandCursor = true; //hand cursor option
    button_replay.events.onInputUp.add(callback, this);
    button_replay.events.onInputOver.add(onOver, this);
    button_replay.events.onInputOut.add(onOut, this);
  },
     
	// --> menu option - 'back button' align
    addMenuOption6: function(button_back,  callback) {
    var button_back = this.add.sprite(game.world.centerX-(92), 460,'back_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      button_back.useHandCursor = true; //hand cursor option

    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      button_back.useHandCursor = true; //hand cursor option

    };
	
    button_back.inputEnabled = true;
	button_back.useHandCursor = true;
	button_back.input.useHandCursor = true; //hand cursor option
    button_back.events.onInputUp.add(callback, this);
    button_back.events.onInputOver.add(onOver, this);
    button_back.events.onInputOut.add(onOut, this);
  },
  
   // --> menu option - 'settings button' align
   addMenuOption7: function(button_settings,  callback) {
    var button_settings = this.add.sprite(game.world.centerX-(-380), 10, 'setting_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
	  button_settings.useHandCursor = true; //hand cursor option
    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
	  button_settings.useHandCursor = true; //hand cursor option
    };

	button_settings.inputEnabled = true;
	button_settings.useHandCursor = true;
	button_settings.input.useHandCursor = true; //hand cursor option
    button_settings.events.onInputUp.add(callback, this);
    button_settings.events.onInputOver.add(onOver, this);
    button_settings.events.onInputOut.add(onOut, this);
	
  },
  
  // --> Audio function management
  manageAudio: function() {
		gameOptions.playMusic =! gameOptions.playMusic;
        music.volume = gameOptions.playMusic ? 1 : 0;
		this.audioButton.animations.play(gameOptions.playMusic);
	},
	
  // --> Menu Game Over
  create: function () {
    this.game.add.sprite(122, 0, 'replay_ground').scale.setTo(0.29);
	this.addMenuOption5 ('button_replay', function () {
	  this.game.state.start(window.onload(this.level)); // replay (restart game)
    }, this.menuGroup);
	
	this.addMenuOption6 ('button_back', function () {   // button back (start game)
	  game.state.start("GameMenu");
    }, this.menuGroup);
	
	this.addMenuOption7('button_settings', function () { // button options
	 game.state.start("Options");
    }, this.menuGroup);
	
	// --> audio button
	this.audioButton = this.add.button(game.world.centerX-(-115), 460, 'sound_button', this.manageAudio, this);
		this.audioButton.anchor.set(1,0);
		this.audioButton.input.useHandCursor = true; //hand cursor option
		this.audioButton.animations.add('true', [0], 10, true);
		this.audioButton.animations.add('false', [1], 10, music.volume, true);
		this.audioButton.animations.play(gameOptions.playMusic);	
  }, 
};

Phaser.Utils.mixinPrototype(GameOver.prototype, mixins);