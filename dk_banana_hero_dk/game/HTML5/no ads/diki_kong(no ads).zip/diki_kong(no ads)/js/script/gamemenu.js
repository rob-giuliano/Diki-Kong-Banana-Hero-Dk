 /* Game menu file
 ================*/
 
'use strict';

// --> GameMenu variable
var GameMenu = function() {};
var diki_Control = {
	_diki_width: 320,
	_diki_height: 480
};

// --> menu config
GameMenu.prototype = {
  menuConfig: {
    startY: 260,
    startX: 30
  },
  
  // --> menu option - 'start button' align
  addMenuOption1: function(button_start,  callback) {
    var button_start = this.add.sprite(game.world.centerX-(-290), 546,'play_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      button_start.useHandCursor = true; //hand cursor option

    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      button_start.useHandCursor = true; //hand cursor option

    };
	
    button_start.inputEnabled = true;
	button_start.useHandCursor = true;
	button_start.input.useHandCursor = true; //hand cursor option
    button_start.events.onInputUp.add(callback, this);
    button_start.events.onInputOver.add(onOver, this);
    button_start.events.onInputOut.add(onOut, this);
  },
  
   // --> menu option - 'setting button' align
   addMenuOption2: function(button_settings,  callback) {
	var button_settings = this.add.sprite( game.world.centerX-(-380), 10,'setting_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
	  button_settings.useHandCursor = true; //hand cursor option
    };
    var onOut = function (target) {
    target.fill = "white";
    target.stroke = "rgba(0,0,0,0)";
	button_settings.useHandCursor = true; //hand cursor option
    };

	button_settings.inputEnabled = true;
	button_settings.useHandCursor = true;
	button_settings.input.useHandCursor = true; //hand cursor option
    button_settings.events.onInputUp.add(callback, this);
    button_settings.events.onInputOver.add(onOver, this);
    button_settings.events.onInputOut.add(onOut, this);
	
  },
  
    // --> menu option - 'credit button' align
    addMenuOption3: function(button_credit,  callback) {
	var button_credit = this.add.sprite(game.world.centerX-(440), 570,'credit_button');
    var onOver = function (target) {
    target.fill = "#FEFFD5";
    target.stroke = "rgba(200,200,200,0.5)";
	button_credit.useHandCursor = true;
    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
	  button_credit.useHandCursor = true; //hand cursor option
    };
    button_credit.inputEnabled = true;
	button_credit.useHandCursor = true;
	button_credit.input.useHandCursor = true; //hand cursor option
    button_credit.events.onInputUp.add(callback, this);
    button_credit.events.onInputOver.add(onOver, this);
    button_credit.events.onInputOut.add(onOut, this);
  },
  
   // --> Audio function management
	manageAudio: function() {
	gameOptions.playMusic =! gameOptions.playMusic;
    music.volume = gameOptions.playMusic ? 1 : 0;
	this.audioButton.animations.play(gameOptions.playMusic);
	},

  create: function () {
	 this.stage.disableVisibilityChange = true;
	 // --> music function
     if (music.name !== "intro_sound" && gameOptions.playMusic) {
      music.stop();
      music = game.add.audio('intro_sound');
      music.loop = true;
      music.play(); 
    }
	// --> audio button 
	this.audioButton = this.add.button(game.world.centerX-(-429), 65,  'sound_button', this.manageAudio, this);
	this.audioButton.anchor.set(1,0);
	this.audioButton.input.useHandCursor = true;
	this.audioButton.animations.add('true', [0], 10, true);
	this.audioButton.animations.add('false', [1], 10, music.volume, true);
	this.audioButton.animations.play(gameOptions.playMusic);
    game.stage.disableVisibilityChange = true;
	game.add.sprite(123, 0, 'start_ground').scale.setTo(0.29);
	
    // --> create a Menu group - only use full if we want to auto adjust the entire menu
	// --> Menu Game Over
    this.menuGroup = game.add.group();
    this.addMenuOption1('button_start', function () {
	 game.state.start(window.onload()); // play (start game)
    }, this.menuGroup);
	
	this.addMenuOption2('button_settings', function () {  // button options
	 game.state.start("Options");
    }, this.menuGroup);
	
	this.addMenuOption3('button_credit', function () { // button credit
	 game.state.start("Credits");
    }, this.menuGroup);

    // --> adding UI icon
    this.randomRotatingIcon = this.add.sprite( game.world.centerX-(-186), 450,'flower');
    this.randomRotatingIcon.anchor.setTo(0.5);
  },
  
  // --> Update function icon rotating
  update: function() {
     this.randomRotatingIcon.angle += 0.2
  }
};

Phaser.Utils.mixinPrototype(GameMenu.prototype, mixins);