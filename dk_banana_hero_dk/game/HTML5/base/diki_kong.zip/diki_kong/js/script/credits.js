 /* Credits file
 ===============*/
 

// --> Credits variable
var Credits = function(game) {};

// --> preload function
Credits.prototype = {
  preload: function () {
    this.optionCount = 1;
    this.creditCount = 0;
  },
  // --> add credit menu option - ' task - author' style && align
  addCredit: function(task, author) {
    var authorStyle = { font: '38pt Chelsea', fill: '#F73400', align: 'center', stroke: 'rgba(0,0,0,0)', strokeThickness: 4};
    var taskStyle = { font: '38pt Chelsea', fill: '#F73400', align: 'center', stroke: 'rgba(0,0,0,0)', strokeThickness: 4};
    var authorText = game.add.text(game.world.centerX, 900, author, authorStyle); // author Text
    var taskText = game.add.text(game.world.centerX, 950, task, taskStyle); // task style
    authorText.anchor.setTo(0.5);
    authorText.stroke = "rgba(0,0,0,0)";
    authorText.strokeThickness = 4; // stroke value 'Author Text'
    taskText.anchor.setTo(0.5);
    taskText.stroke = "rgba(0,0,0,0)";
    taskText.strokeThickness = 4;  // stroke value 'Task Text'
    game.add.tween(authorText).to( { y: -300 }, 20000, Phaser.Easing.Cubic.Out, true, this.creditCount * 10000);
    game.add.tween(taskText).to( { y: -200 }, 20000, Phaser.Easing.Cubic.Out, true, this.creditCount * 10000);
    this.creditCount ++;
  },
  // -->  add menu option - 'callback - text'  font && align
  addMenuOption: function(text, callback) {
    var optionStyle = {
      font: '30pt Modak',
      fill: 'white',
      align: 'left',
      stroke: 'rgba(0,0,0,0)',
      strokeThickness: 4    // stroke value
    };
    var txt = game.add.text(10, (this.optionCount * 80) + 450, text, optionStyle); // default variable 'txt'
    txt.stroke = "rgba(0,0,0,0)"; // stroke value 'txt'
    txt.strokeThickness = 4;
    var onOver = function (target) {
      target.fill = "#FEFFD5"; // target fill color
      target.stroke = "rgba(200,200,200,0.5)";
      txt.useHandCursor = true;
    };
    var onOut = function (target) {
      target.fill = "#fff"; // target fill color
      target.stroke = "rgba(0,0,0,0)";
      txt.useHandCursor = false; //hand cursor option
    };
	
    txt.inputEnabled = true;
    txt.events.onInputUp.add(callback, this);
    txt.events.onInputOver.add(onOver, this);
    txt.events.onInputOut.add(onOut, this);
    this.optionCount ++;
  },
  
  // --> menu option - 'back button' align
  addMenuOption4: function (button_back,  callback) {
    var button_back = this.add.sprite(game.world.centerX-(440), 570,'back_button');
    var onOver = function (target) {
      target.fill = "#FEFFD5";
      target.stroke = "rgba(200,200,200,0.5)";
      button_back.useHandCursor = true;  //hand cursor option

    };
    var onOut = function (target) {
      target.fill = "white";
      target.stroke = "rgba(0,0,0,0)";
      button_back.useHandCursor = true; //hand cursor option
    };
	
    button_back.inputEnabled = true;
	button_back.useHandCursor = true;
	button_back.input.useHandCursor = true; //hand cursor option
    button_back.events.onInputUp.add(callback, this);
    button_back.events.onInputOver.add(onOver, this);
    button_back.events.onInputOut.add(onOut, this);
  },
  
  create: function () {
    this.stage.disableVisibilityChange = true;
	// --> music function
    if (gameOptions.playMusic) {
      music.stop();
      music = game.add.audio('credit');
	  music.loop = true;
      music.play();
    }
	
	// --> sprite create credit group - 'Text'
	game.add.sprite(100, 0, 'credit_ground').scale.setTo(0.29);
	this.addCredit('(credits)', 'Many Thanks');
	this.addCredit('- Developer -', 'Rob Giuliano');
	this.addCredit('- Tester -', 'Timothy Sam Dixon');
    this.addCredit('- Sound -', 'Wallter Studio');
    
    this.addCredit('- Graphic Design -', 'Austin Pickett');
    this.addCredit('(graphic)', 'craftpix.net');
	this.addCredit('(graphic)', 'pngtree.com');
    this.addCredit('(framework)', 'phaser.io');
	this.menuGroup = game.add.group();
  
     // --> Menu Button Back
    this.addMenuOption4 ('button_back', function () {
	  game.state.start("GameMenu");
    }, this.menuGroup);
  }

};
