 /* Splash file
 ===============*/

'use strict';

// --> Splash variable
var Splash = function () {};
Splash.prototype = {

  // --> load scripts
  loadScripts: function () {  
    game.load.script('style', 'js/library/style.js');
    game.load.script('mixins', 'js/library/mixins.js');
    game.load.script('WebFont', 'js/webfontloader.js');
    game.load.script('gamemenu','js/script/gamemenu.js');
	game.load.script('Diki_Kong', 'js/script/game.js');
	game.load.script('diki_kong', 'js/script/game.js');
	game.load.script('startx', 'js/script/game.js');
	game.load.script('game', 'js/script/game.js');
	game.load.script('Game', 'js/script/updata.js');
    game.load.script('gameover','js/script/gameover.js');
    game.load.script('credits', 'js/script/credits.js');
    game.load.script('options', 'js/script/options.js');
	game.load.script('joystick', 'js/gamepad.js');
	
  },
  
  groundSound: function () {
    game.load.audio('credit', 'sound/credit_sound.ogg');
	game.load.audio('level_sound', 'sound/level_sound.ogg');
  },
  
  // varios freebies found from google image search
  loadImages: function () {
    game.load.image('options-bg', 'images/menu/options-bg.jpg');
  },

 // --> load fonts
  loadFonts: function () {
    WebFontConfig = {
      custom: {
        families: ['Chelsea', 'Chelsea'], // font 'Chelsea' families
        urls: ['style/theminion.css']
      },
      google: {
          families: ['Sniglet', 'Modak'] // font 'Siglet' families 'Modak'
      }
    }
  },
  
  init: function () {
    this.loadingBar = game.make.sprite(game.world.centerX-(480), 0, "loading");
    this.logo       = game.make.sprite(game.world.centerX, 250, 'brand');
    this.status     = game.make.text(game.world.centerX, 380);
	this.logo_dev   = game.make.sprite(game.world.centerX-(-340), 590, 'logo_dev');
    utils.centerGameObjects([this.logo, this.status]);
	
  },

  preload: function () {
    game.stage.backgroundColor = "#cff3ee"; // ground intro
    game.add.existing(this.logo).scale.setTo(0.5);
	game.add.existing(this.logo_dev).scale.setTo(0.5);
    game.add.existing(this.loadingBar);
    game.add.existing(this.status);
    this.addLoadingIcon()
    this.load.setPreloadSprite(this.loadingBar);

    this.loadScripts(); //run scripts function
    this.loadImages();  //run images function
    this.loadFonts();   //run fonts function
	this.groundSound();

  },

  // --> load update function
  loadUpdate: function(){
    this.loadingIcon.angle += 8     //angle loading design icon
	this.loadingIcon_1.angle += 8  //angle loading design icon  -> 1
	this.loadingIcon_2.angle += 8  //angle loading design  icon -> 2
  },
  
  addLoadingIcon: function() {
    // --> adding UI icon
    this.loadingIcon = this.add.sprite(game.world.centerX-(-8), 405, 'loader', { fill : '#FF0000', font : '64px FontAwesome' }); // loader design
	this.loadingIcon_1 = this.add.sprite(game.world.centerX-(-51), 405, 'loader_min_r', { fill : '#FF0000', font : '64px FontAwesome' }); // loader design right
    this.loadingIcon_2 = this.add.sprite(game.world.centerX-(35), 405, 'loader_min_l', { fill : '#FF0000', font : '64px FontAwesome' });  // loader design left
	this.loadingIcon.anchor.setTo(0.5);
	this.loadingIcon_1.anchor.setTo(0.5);
	this.loadingIcon_2.anchor.setTo(0.5);
  },

 // --> Game stat function
  addGameStates: function () {
    game.state.add("GameMenu",GameMenu);
    game.state.add("Diki_Kong",Diki_Kong);
	game.state.add("startx",startx);
	game.state.add("Game",Game);
	game.state.add("diki_kong",diki_kong);
    game.state.add("GameOver",GameOver);
    game.state.add("Credits",Credits);
    game.state.add("Options",Options);
  },

   // --> music function intro
  addGameMusic: function () {
    music = game.add.audio('intro_sound');
    music.loop = true;
  },
  
  // --> Device ratio manager scale
  initDeviceRatio: function(){
    if (this.game.device.desktop){
		this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		this.game.scale.windowConstraints.bottom = 'visual'
    }
    else
    {
        this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		this.game.scale.windowConstraints.bottom = 'visual'	

    }
  },

  create: function() {
    this.addGameStates();    // game states function
    this.addGameMusic();     // game music function
    this.initDeviceRatio(); // device ratio function
	
	// --> setting timeout game start 'Menu' - default : 1000
    setTimeout(function () {
      game.state.start("GameMenu"); //game start menu
    }, 1000);
  }
};

